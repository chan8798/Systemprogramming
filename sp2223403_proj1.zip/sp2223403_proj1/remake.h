#pragma once
char* trim_left(char* sr);
char* trim_right(char* sr);
char* trim(char* sr);