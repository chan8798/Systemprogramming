#pragma once
char findhex(char* str);