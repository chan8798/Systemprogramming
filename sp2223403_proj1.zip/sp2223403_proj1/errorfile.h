#pragma once
void errorfile(FILE* fp);